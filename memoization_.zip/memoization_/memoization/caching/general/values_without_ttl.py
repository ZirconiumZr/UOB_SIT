
def make_cache_value(result, ttl):
    return result


def is_cache_value_valid(value):
    return True


def retrieve_result_from_cache_value(value):
    return value
